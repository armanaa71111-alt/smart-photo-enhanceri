# Smart Photo Enhancer (Flutter)

A minimal **offline** smart photo enhancer app. Pick an image, adjust sliders (brightness, contrast, saturation), optional auto white balance and auto contrast, plus denoise & sharpen. All processing runs on-device using the pure Dart `image` package.

## Run
```bash
flutter pub get
flutter run
# or build APK
flutter build apk --release
```

## Notes
- Uses `compute()` to process in an isolate so the UI stays responsive.
- Save/Share via the platform share sheet.